import React, { Component } from "react";
class App extends Component {
  render() {
    return (
      <div>
        <h2>Welcome</h2>
      </div>
    );
  }
}
export default App;
